import React from 'react';
import { Heart, Sparkles } from 'lucide-react';
import { Deck } from '../data/decks';

interface DeckSelectionProps {
  decks: Deck[];
  onDeckSelect: (deck: Deck) => void;
}

const DeckSelection: React.FC<DeckSelectionProps> = ({ decks, onDeckSelect }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-rose-100 p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Heart className="w-8 h-8 text-rose-400 animate-pulse" />
            <h1 className="text-4xl md:text-5xl font-light text-rose-800 tracking-wide">
              Cartas do Coração
            </h1>
            <Heart className="w-8 h-8 text-rose-400 animate-pulse" />
          </div>
          <p className="text-rose-600 text-lg font-light max-w-2xl mx-auto leading-relaxed">
            Escolha um deck e descubra perguntas que aprofundam sua conexão
          </p>
        </div>

        {/* Deck Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {decks.map((deck, index) => (
            <div
              key={deck.subject}
              className="deck-card group cursor-pointer transform transition-all duration-500 hover:scale-105 hover:-translate-y-2"
              onClick={() => onDeckSelect(deck)}
              style={{
                animationDelay: `${index * 100}ms`
              }}
            >
              <div className="relative bg-white/80 backdrop-blur-sm rounded-2xl p-8 shadow-lg border border-rose-100 hover:shadow-2xl hover:border-rose-200 transition-all duration-500">
                {/* Decorative elements */}
                <div className="absolute top-4 right-4 opacity-30 group-hover:opacity-60 transition-opacity duration-300">
                  <Sparkles className="w-6 h-6 text-rose-300" />
                </div>
                <div className="absolute bottom-4 left-4 opacity-20 group-hover:opacity-40 transition-opacity duration-300">
                  <Heart className="w-4 h-4 text-rose-300" />
                </div>

                {/* Card content */}
                <div className="space-y-4">
                  <div className="h-16 flex items-center justify-center">
                    <h3 className="text-xl font-medium text-rose-800 text-center leading-tight">
                      {deck.title}
                    </h3>
                  </div>
                  
                  <div className="border-t border-rose-100 pt-4">
                    <div className="flex items-center justify-between text-sm text-rose-600">
                      <span className="font-light">
                        {deck.content.length} cartas
                      </span>
                      <div className="flex gap-1">
                        {[...Array(3)].map((_, i) => (
                          <div 
                            key={i} 
                            className="w-2 h-2 bg-rose-300 rounded-full opacity-60"
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Hover effect overlay */}
                <div className="absolute inset-0 bg-gradient-to-br from-rose-200/20 to-pink-200/20 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="text-center mt-16 opacity-60">
          <p className="text-rose-600 font-light">
            Feito com amor para fortalecer conexões
          </p>
        </div>
      </div>
    </div>
  );
};

export default DeckSelection;