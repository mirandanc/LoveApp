import React, { useState, useEffect } from 'react';
import { ArrowLeft, Heart, RotateCcw, Sparkles } from 'lucide-react';
import { Deck, Card } from '../data/decks';

interface CardViewProps {
  deck: Deck;
  onBack: () => void;
}

const CardView: React.FC<CardViewProps> = ({ deck, onBack }) => {
  const [currentCard, setCurrentCard] = useState<Card | null>(null);
  const [usedCards, setUsedCards] = useState<Set<string>>(new Set());
  const [isFlipped, setIsFlipped] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);
  const [deckComplete, setDeckComplete] = useState(false);

  const getRandomCard = () => {
    const availableCards = deck.content.filter(card => !usedCards.has(card.id));
    
    if (availableCards.length === 0) {
      setDeckComplete(true);
      return null;
    }
    
    const randomIndex = Math.floor(Math.random() * availableCards.length);
    return availableCards[randomIndex];
  };

  const handleCardClick = () => {
    if (isAnimating) return;

    if (!isFlipped) {
      // First click - flip and show card
      setIsAnimating(true);
      setIsFlipped(true);
      
      const newCard = getRandomCard();
      if (newCard) {
        setTimeout(() => {
          setCurrentCard(newCard);
          setUsedCards(prev => new Set(prev).add(newCard.id));
          setIsAnimating(false);
        }, 300);
      }
    } else {
      // Subsequent clicks - slide down and show new card
      setIsAnimating(true);
      
      setTimeout(() => {
        const newCard = getRandomCard();
        if (newCard) {
          setCurrentCard(newCard);
          setUsedCards(prev => new Set(prev).add(newCard.id));
        }
        setIsAnimating(false);
      }, 300);
    }
  };

  const resetDeck = () => {
    setUsedCards(new Set());
    setCurrentCard(null);
    setIsFlipped(false);
    setDeckComplete(false);
    setIsAnimating(false);
  };

  useEffect(() => {
    // Initial entrance animation
    setTimeout(() => {
      setIsAnimating(false);
    }, 800);
  }, []);

  if (deckComplete) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-rose-100 flex items-center justify-center p-6">
        <div className="text-center space-y-8 animate-fade-in">
          <div className="space-y-4">
            <Heart className="w-20 h-20 text-rose-400 mx-auto animate-pulse" />
            <h2 className="text-4xl font-light text-rose-800">
              Deck Completo!
            </h2>
            <p className="text-rose-600 text-lg max-w-md mx-auto leading-relaxed">
              Vocês exploraram todas as cartas de "{deck.title}". 
              Que momentos especiais foram compartilhados?
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={resetDeck}
              className="flex items-center gap-2 px-8 py-3 bg-white/80 backdrop-blur-sm text-rose-700 rounded-full border border-rose-200 hover:bg-white hover:shadow-lg transition-all duration-300 font-medium"
            >
              <RotateCcw className="w-4 h-4" />
              Recomeçar Deck
            </button>
            <button
              onClick={onBack}
              className="flex items-center gap-2 px-8 py-3 bg-rose-500 text-white rounded-full hover:bg-rose-600 hover:shadow-lg transition-all duration-300 font-medium"
            >
              <ArrowLeft className="w-4 h-4" />
              Escolher Outro Deck
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-rose-100 flex items-center justify-center p-6">
      <div className="w-full max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <button
            onClick={onBack}
            className="inline-flex items-center gap-2 text-rose-600 hover:text-rose-700 font-medium mb-6 transition-colors duration-200"
          >
            <ArrowLeft className="w-4 h-4" />
            Voltar aos Decks
          </button>
          
          <div className="space-y-2">
            <h1 className="text-3xl font-light text-rose-800">
              {deck.title}
            </h1>
            <div className="flex items-center justify-center gap-2 text-rose-600">
              <span className="text-sm font-light">
                {usedCards.size} de {deck.content.length} cartas
              </span>
              <div className="flex gap-1">
                {Array.from({ length: Math.min(5, deck.content.length) }).map((_, i) => (
                  <div 
                    key={i} 
                    className={`w-2 h-2 rounded-full transition-colors duration-300 ${
                      i < (usedCards.size / deck.content.length) * 5 
                        ? 'bg-rose-400' 
                        : 'bg-rose-200'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Card Container */}
        <div className="relative h-96 flex items-center justify-center">
          <div 
            className={`card-container ${isFlipped ? 'flipped' : ''} ${isAnimating ? 'animating' : ''}`}
            onClick={handleCardClick}
          >
            {/* Card Back */}
            <div className="card card-back">
              <div className="card-content bg-gradient-to-br from-rose-400 to-pink-500 text-white">
                <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent rounded-2xl" />
                <div className="relative z-10 flex flex-col items-center justify-center h-full text-center space-y-4">
                  <Heart className="w-16 h-16 animate-pulse" />
                  <h3 className="text-2xl font-light">
                    {deck.title}
                  </h3>
                  <p className="text-rose-100 font-light">
                    Toque para revelar
                  </p>
                  <div className="flex gap-2">
                    {[...Array(3)].map((_, i) => (
                      <Sparkles key={i} className="w-4 h-4 animate-pulse" style={{ animationDelay: `${i * 200}ms` }} />
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Card Front */}
            <div className="card card-front">
              <div className="card-content bg-white/90 backdrop-blur-sm text-rose-800">
                <div className="absolute top-6 right-6 opacity-30">
                  <Sparkles className="w-6 h-6 text-rose-300" />
                </div>
                <div className="absolute bottom-6 left-6 opacity-20">
                  <Heart className="w-4 h-4 text-rose-300" />
                </div>
                
                <div className="relative z-10 flex flex-col items-center justify-center h-full text-center p-8">
                  <div className="space-y-6">
                    <div className="w-12 h-12 bg-rose-100 rounded-full flex items-center justify-center mb-4">
                      <Heart className="w-6 h-6 text-rose-500" />
                    </div>
                    
                    {currentCard && (
                      <p className="text-lg leading-relaxed font-light max-w-lg">
                        {currentCard.text}
                      </p>
                    )}
                    
                    <div className="pt-4">
                      <p className="text-sm text-rose-500 font-light">
                        Toque para próxima carta
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Instruction */}
        <div className="text-center mt-8">
          <p className="text-rose-600 font-light">
            {!isFlipped 
              ? "Clique na carta para começar esta jornada"
              : "Clique para descobrir a próxima pergunta"
            }
          </p>
        </div>
      </div>
    </div>
  );
};

export default CardView;