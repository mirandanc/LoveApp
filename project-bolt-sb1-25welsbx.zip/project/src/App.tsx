import React, { useState } from 'react';
import DeckSelection from './components/DeckSelection';
import CardView from './components/CardView';
import { decks } from './data/decks';
import { Deck } from './data/decks';

function App() {
  const [selectedDeck, setSelectedDeck] = useState<Deck | null>(null);

  const handleDeckSelect = (deck: Deck) => {
    setSelectedDeck(deck);
  };

  const handleBack = () => {
    setSelectedDeck(null);
  };

  return (
    <div className="App">
      {selectedDeck ? (
        <CardView deck={selectedDeck} onBack={handleBack} />
      ) : (
        <DeckSelection decks={decks} onDeckSelect={handleDeckSelect} />
      )}
    </div>
  );
}

export default App;