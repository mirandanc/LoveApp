export const decks = [
  {
    "subject": "Sobre Você e Sobre Mim",
    "title": "Sobre Você e Sobre Mim",
    "content": [
      {
        "id": "about_you_me_01",
        "text": "Se pudesse passar um dia inteiro fazendo algo que você ama, o que escolheria?"
      },
      {
        "id": "about_you_me_02",
        "text": "Qual foi o momento em que você se sentiu mais orgulhoso(a) de si mesmo(a)?"
      },
      {
        "id": "about_you_me_03",
        "text": "Que cinco palavras você usaria para descrever quem eu sou para você?"
      },
      {
        "id": "about_you_me_04",
        "text": "Qual memória da infância faz você sorrir até hoje?"
      },
      {
        "id": "about_you_me_05",
        "text": "Qual hábito diário faz você se sentir mais você mesmo(a)?"
      },
      {
        "id": "about_you_me_06",
        "text": "O que você considera essencial para manter seu bem-estar emocional?"
      },
      {
        "id": "about_you_me_07",
        "text": "Qual foi o maior desafio que você superou e o que aprendeu com ele?"
      },
      {
        "id": "about_you_me_08",
        "text": "O que desperta sua paixão e faz você perder a noção do tempo?"
      },
      {
        "id": "about_you_me_09",
        "text": "Quais três experiências você sonha em viver juntos?"
      }
    ]
  },
  {
    "subject": "Metas, Sonhos e Futuro",
    "title": "Metas, Sonhos e Futuro",
    "content": [
      {
        "id": "goals_dreams_future_01",
        "text": "Se dinheiro e tempo não fossem limites, o que você faria amanhã?"
      },
      {
        "id": "goals_dreams_future_02",
        "text": "Que hábito você gostaria de cultivar no próximo ano para seu crescimento pessoal?"
      },
      {
        "id": "goals_dreams_future_03",
        "text": "Como imagina nosso relacionamento quando estivermos com 60 anos?"
      },
      {
        "id": "goals_dreams_future_04",
        "text": "Qual pequeno passo você pode dar hoje para chegar mais perto de um grande sonho?"
      },
      {
        "id": "goals_dreams_future_05",
        "text": "Como posso ser seu maior incentivo na busca pelos seus objetivos?"
      },
      {
        "id": "goals_dreams_future_06",
        "text": "Que novas aventuras você quer vivenciar comigo nos próximos anos?"
      },
      {
        "id": "goals_dreams_future_07",
        "text": "Que medos te impedem de avançar e como podemos enfrentá-los juntos?"
      },
      {
        "id": "goals_dreams_future_08",
        "text": "O que podemos criar em conjunto que represente nossa maior paixão compartilhada?"
      },
      {
        "id": "goals_dreams_future_09",
        "text": "Qual impacto você deseja deixar no mundo como casal?"
      }
    ]
  },
  {
    "subject": "Sexo e Intimidade",
    "title": "Sexo e Intimidade",
    "content": [
      {
        "id": "sex_intimacy_01",
        "text": "O que faz você se sentir mais desejado(a) e conectado(a) comigo?"
      },
      {
        "id": "sex_intimacy_02",
        "text": "Qual gesto de carinho te faz derreter instantaneamente?"
      },
      {
        "id": "sex_intimacy_03",
        "text": "Como podemos criar um clima de romance antes de começarmos?"
      },
      {
        "id": "sex_intimacy_04",
        "text": "O que impede você de se entregar por completo e como posso ajudar?"
      },
      {
        "id": "sex_intimacy_05",
        "text": "Há algo novo que você gostaria de experimentar comigo?"
      },
      {
        "id": "sex_intimacy_06",
        "text": "Que convite ou fantasia faz seu coração bater mais forte?"
      },
      {
        "id": "sex_intimacy_07",
        "text": "O que eu faço que te faz sentir amado(a) durante a intimidade?"
      },
      {
        "id": "sex_intimacy_08",
        "text": "Como podemos manter a chama acesa mesmo nas rotinas mais agitadas?"
      },
      {
        "id": "sex_intimacy_09",
        "text": "Qual é seu maior desejo de conexão íntima que ainda não realizei?"
      }
    ]
  },
  {
    "subject": "Trabalho e Dinheiro",
    "title": "Trabalho e Dinheiro",
    "content": [
      {
        "id": "work_money_01",
        "text": "O que te motiva a acordar animado(a) todas as manhãs?"
      },
      {
        "id": "work_money_02",
        "text": "Como você define segurança financeira?"
      },
      {
        "id": "work_money_03",
        "text": "Que equilíbrio ideal entre carreira e vida pessoal você busca?"
      },
      {
        "id": "work_money_04",
        "text": "Qual foi o maior aprendizado que seu trabalho lhe trouxe?"
      },
      {
        "id": "work_money_05",
        "text": "Onde podemos cortar excessos para economizar juntos?"
      },
      {
        "id": "work_money_06",
        "text": "Que hábito de consumo você quer transformar neste ano?"
      },
      {
        "id": "work_money_07",
        "text": "Como podemos celebrar cada conquista financeira, grande ou pequena?"
      },
      {
        "id": "work_money_08",
        "text": "Quais inseguranças financeiras você ainda carrega?"
      },
      {
        "id": "work_money_09",
        "text": "Como nossa situação financeira afeta nossos planos de viagem ou lazer?"
      }
    ]
  },
  {
    "subject": "Comunicação e Solução de Conflitos",
    "title": "Comunicação e Solução de Conflitos",
    "content": [
      {
        "id": "communication_conflict_01",
        "text": "Qual é sua maneira favorita de resolver um desentendimento?"
      },
      {
        "id": "communication_conflict_02",
        "text": "O que você valoriza em uma conversa honesta?"
      },
      {
        "id": "communication_conflict_03",
        "text": "Quando o humor ajuda ou atrapalha nossas discussões?"
      },
      {
        "id": "communication_conflict_04",
        "text": "Que assunto você sente que deixamos para depois com medo de magoar?"
      },
      {
        "id": "communication_conflict_05",
        "text": "O que eu faço que interrompe sua vontade de dialogar?"
      },
      {
        "id": "communication_conflict_06",
        "text": "Como podemos escutar mais atentamente um ao outro?"
      },
      {
        "id": "communication_conflict_07",
        "text": "Que gesto meu traz conforto em momentos de tensão?"
      },
      {
        "id": "communication_conflict_08",
        "text": "Alguma coisa que disse no passado você gostaria de revisitar?"
      },
      {
        "id": "communication_conflict_09",
        "text": "Que regra de comunicação podemos criar para evitar mal-entendidos?"
      }
    ]
  },
  {
    "subject": "Tempo de Qualidade, Limites e Compatibilidade",
    "title": "Tempo de Qualidade, Limites e Compatibilidade",
    "content": [
      {
        "id": "quality_time_boundaries_compatibility_01",
        "text": "Qual nova atividade você gostaria de experimentar comigo neste mês?"
      },
      {
        "id": "quality_time_boundaries_compatibility_02",
        "text": "Que limite pessoal você precisa que eu respeite mais?"
      },
      {
        "id": "quality_time_boundaries_compatibility_03",
        "text": "Você já abriu mão de algo importante por nós? Como se sentiu?"
      },
      {
        "id": "quality_time_boundaries_compatibility_04",
        "text": "Que tradição podemos criar para celebrarmos semanalmente?"
      },
      {
        "id": "quality_time_boundaries_compatibility_05",
        "text": "Como podemos ajudar amigos e familiares a entender nossos limites?"
      },
      {
        "id": "quality_time_boundaries_compatibility_06",
        "text": "O quão importante é para você comemorar datas especiais?"
      },
      {
        "id": "quality_time_boundaries_compatibility_07",
        "text": "Que momento sozinho te recarrega para depois estarmos juntos?"
      },
      {
        "id": "quality_time_boundaries_compatibility_08",
        "text": "Como podemos equilibrar nosso tempo para que ambos se sintam atendidos?"
      },
      {
        "id": "quality_time_boundaries_compatibility_09",
        "text": "Que novas comunidades ou grupos gostaríamos de explorar juntos?"
      }
    ]
  },
  {
    "subject": "Saúde e Estilo de Vida",
    "title": "Saúde e Estilo de Vida",
    "content": [
      {
        "id": "health_lifestyle_01",
        "text": "Que hábito de bem-estar você quer começar a praticar em dupla?"
      },
      {
        "id": "health_lifestyle_02",
        "text": "Como podemos apoiar um ao outro em desafios de saúde?"
      },
      {
        "id": "health_lifestyle_03",
        "text": "Que impacto o consumo consciente tem em nossa rotina?"
      },
      {
        "id": "health_lifestyle_04",
        "text": "Como você se sente ao falar sobre suas vulnerabilidades de saúde?"
      },
      {
        "id": "health_lifestyle_05",
        "text": "De que forma posso ser seu parceiro(a) de treino e motivação?"
      },
      {
        "id": "health_lifestyle_06",
        "text": "Que atividade de autocuidado você gostaria de experimentar comigo?"
      },
      {
        "id": "health_lifestyle_07",
        "text": "Como podemos manter hábitos saudáveis mesmo em dias corridos?"
      },
      {
        "id": "health_lifestyle_08",
        "text": "Que mudança em casa facilitaria uma vida mais saudável?"
      },
      {
        "id": "health_lifestyle_09",
        "text": "Como práticas espirituais contribuem para seu equilíbrio diário?"
      }
    ]
  },
  {
    "subject": "Respeito e Compromisso",
    "title": "Respeito e Compromisso",
    "content": [
      {
        "id": "respect_commitment_01",
        "text": "O que significa cumprir nossa palavra um com o outro?"
      },
      {
        "id": "respect_commitment_02",
        "text": "Como posso demonstrar mais apreço pelo seu espaço pessoal?"
      },
      {
        "id": "respect_commitment_03",
        "text": "Que atitude você valoriza como sinal de respeito diário?"
      },
      {
        "id": "respect_commitment_04",
        "text": "Como podemos reforçar nossa aliança em pequenas ações?"
      },
      {
        "id": "respect_commitment_05",
        "text": "Como equilibrar nossas necessidades sem ferir o outro?"
      },
      {
        "id": "respect_commitment_06",
        "text": "Em que momento você mais sentiu meu comprometimento?"
      },
      {
        "id": "respect_commitment_07",
        "text": "Como conciliar liberdade individual e conexões profundas?"
      },
      {
        "id": "respect_commitment_08",
        "text": "O que te faz sentir seguro(a) para expor seus limites?"
      },
      {
        "id": "respect_commitment_09",
        "text": "Que sinal indicaria que nossas promessas estão sendo desrespeitadas?"
      }
    ]
  },
  {
    "subject": "Date Surpresa",
    "title": "Date Surpresa",
    "content": [
      {
        "id": "surprise_date_01",
        "text": "Imaginem um lugar impossível de visitar – para onde iríamos juntos?"
      },
      {
        "id": "surprise_date_02",
        "text": "Façam algo inesperado agora: escolham um desafio criativo em 5 minutos."
      },
      {
        "id": "surprise_date_03",
        "text": "Cada um propõe 3 perguntas relâmpago para uma rodada divertida."
      },
      {
        "id": "surprise_date_04",
        "text": "Criem um mini-evento temático caseiro e convidem pelo menos um amigo em vídeo."
      },
      {
        "id": "surprise_date_05",
        "text": "Telefonem para alguém que marcou suas vidas e compartilhem uma boa lembrança."
      },
      {
        "id": "surprise_date_06",
        "text": "Revelem pequenos segredos que sempre quiseram dividir e façam um pacto de realizá-los."
      },
      {
        "id": "surprise_date_07",
        "text": "Organize em segredo um roteiro de atividades surpresa para o próximo fim de semana."
      },
      {
        "id": "surprise_date_08",
        "text": "Planejem uma viagem-relâmpago de um dia para descobrir algo novo juntos."
      },
      {
        "id": "surprise_date_09",
        "text": "Listem 5 experiências que precisamos viver antes de envelhecer juntos."
      }
    ]
  },
  {
    "subject": "Nossa História",
    "title": "Nossa História",
    "content": [
      {
        "id": "our_history_01",
        "text": "Quando nos conhecemos, qual momento te fez sorrir instantaneamente?"
      },
      {
        "id": "our_history_02",
        "text": "Qual foi o gesto mais doce que você lembra do nosso início?"
      },
      {
        "id": "our_history_03",
        "text": "Que virada em nossa jornada mudou tudo para melhor?"
      },
      {
        "id": "our_history_04",
        "text": "Se pudesse reviver apenas um encontro nosso, qual seria e por quê?"
      },
      {
        "id": "our_history_05",
        "text": "Qual história boba nossa você nunca cansa de relembrar?"
      },
      {
        "id": "our_history_06",
        "text": "Como descreveria nossa trajetória para alguém que não nos conhece?"
      },
      {
        "id": "our_history_07",
        "text": "Que lição valiosa tiramos juntos ao longo do tempo?"
      },
      {
        "id": "our_history_08",
        "text": "Se pudesse nos levar a qualquer parte do mundo, para onde seria?"
      },
      {
        "id": "our_history_09",
        "text": "Quais promessas essenciais queremos renovar um para o outro?"
      }
    ]
  }
];

export interface Card {
  id: string;
  text: string;
}

export interface Deck {
  subject: string;
  title: string;
  content: Card[];
}